
str = "abcdef=ghijkl;,mn"
startpos=str.find('=')
endpos = str[startpos:].find(';')+startpos
#print str[:startpos]+str[endpos+1:]
#print str[startpos:endpos+1]
print str[:startpos]+str[endpos+1:]